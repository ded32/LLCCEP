#include "opcodes.hpp"

#if defined(__linux__) || defined(__APPLE__)
	#include <sys/mman.h>
#elif defined(_WIN32)
	#include <windows.h>
#endif

#include <vector>

int main()
{
	std::vector<LLCCEP_JIT::BYTE> program;

	double *val = new double[2];

	LLCCEP_JIT::AppendRET(program);

#if defined(__linux__) || defined(__APPLE__)
	mprotect(&program[0], program.size(), PROT_READ | PROT_WRITE | PROT_EXEC);
#else
	VirtualProtect(&program[0], program.size(), PAGE_EXECUTE_READWRITE, 0);
#endif

	asm
	(
		"call *%0"
		:
		:"r"(&program[0])
		:"eax", "ebx", "ecx"
	);

	return 0;
}
